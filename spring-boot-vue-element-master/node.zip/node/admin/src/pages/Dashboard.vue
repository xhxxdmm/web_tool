<template>
<section>
  首页
</section>
</template>

<script>
export default {}
</script>

<style scoped>
</style>
